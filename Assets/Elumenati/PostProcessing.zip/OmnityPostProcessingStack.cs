﻿using UnityEngine;
using UnityEngine.Rendering.PostProcessing;

#if UNITY_EDITOR

using UnityEditor;

#endif

public class OmnityPostProcessingStack : MonoBehaviour {

    [Header("in the folder /Packages/Post Processing/PostProcessing/")]
    [Header("This should be connected to PostProcessResources.asset")]
    public PostProcessResources ppResources;

    // Start is called before the first frame update
    private void OnEnable() {
        if(ppResources == null) {
            Debug.LogError("ERROR: This script needs the Post Processing V2 Stack from the package manager. This should be connected to PostProcessResources.asset in the folder /Packages/Post Processing/PostProcessing/");
        }

        Omnity.onReloadEndCallback += ApplyEffects;
    }

    private void OnDisable() {
        Omnity.onReloadEndCallback -= ApplyEffects;
    }

    private void ApplyEffects(Omnity anOmnity) {
        for(int i = 0; i < anOmnity.cameraArray.Length; i++) {
            var firstPassOmnityCamera = anOmnity.cameraArray[i];
            Apply(firstPassOmnityCamera.postProcessOptions, anOmnity, firstPassOmnityCamera.myCamera, ppResources);
        }
        for(int i = 0; i < anOmnity.finalPassCameras.Length; i++) {
            var secondPassCamera = anOmnity.finalPassCameras[i];
            Apply(secondPassCamera.postProcessOptions, anOmnity, secondPassCamera.myCamera, ppResources);
        }
    }

    static private void Apply(PostProcessOptions options, Omnity anOmnity, Camera camera, PostProcessResources ppResources) {
        PostProcessLayer layer;
        if(!camera) {
            return;
        }
        switch(options.type) {
            case PostProcessOptions.PostProcessType.None:
            break;

            case PostProcessOptions.PostProcessType.ByGameObjectLayer:
            layer = Add(camera, ppResources);
            ApplyAA(anOmnity, options, layer);
            if(camera)
                layer.volumeLayer.value = 1 << camera.gameObject.layer;
            break;

            case PostProcessOptions.PostProcessType.ByLayerIndicies:
            layer = Add(camera, ppResources);
            ApplyAA(anOmnity, options, layer);
            layer.volumeLayer.value = options.layerMaskInt;

            break;

            case PostProcessOptions.PostProcessType.ByLayerNames:
            layer = Add(camera, ppResources);
            layer.volumeLayer = LayerMask.GetMask(options.layerNames);
            ApplyAA(anOmnity, options, layer);
            break;

            case PostProcessOptions.PostProcessType.CopyMainCamera:
            var mc = GetMainCamera_PostProcessLayer(anOmnity);
            if(mc) {
                layer = Add(camera, ppResources);
                layer.volumeLayer = mc.volumeLayer;
                camera.gameObject.layer = mc.gameObject.layer;
                ApplyAA(anOmnity, options, layer);
            }
            break;

            default:
            Debug.Log("Unknown mode " + options.type);
            break;
        }
    }

    static private PostProcessLayer Add(Camera camera, PostProcessResources ppResources) {
        PostProcessLayer layer = camera.gameObject.GetComponent<PostProcessLayer>() as PostProcessLayer;
        if(!layer) {
            layer = camera.gameObject.AddComponent<PostProcessLayer>() as PostProcessLayer;
            layer.Init(ppResources);
            layer.volumeTrigger = camera.transform;
        }
        return layer;
    }

    static private PostProcessLayer GetMainCamera_PostProcessLayer(Omnity anOmnity) {
        var m_camra = anOmnity.gameObject.GetComponent<Camera>();
        if(!m_camra) {
            m_camra = Camera.main;
        }
        if(m_camra) {
            return m_camra.gameObject.GetComponent<PostProcessLayer>();
        }
        return null;
    }

    static private void ApplyAA(Omnity anOmnity, PostProcessOptions options, PostProcessLayer layer) {
        if(layer) {
            var mainLayer = GetMainCamera_PostProcessLayer(anOmnity);
            if(options.type == PostProcessOptions.PostProcessType.CopyMainCamera && mainLayer) {
                layer.antialiasingMode = mainLayer.antialiasingMode;
            } else {
                int aa = (int)options.antialiasingOptions;
                layer.antialiasingMode = (PostProcessLayer.Antialiasing)aa;
            }
        }
    }
}

#if UNITY_EDITOR

public class EffectHelperEditor : EditorWindow {

    private class XAllPostprocessor : AssetPostprocessor {

        private static void OnPostprocessAllAssets(string[] importedAssets, string[] deletedAssets, string[] movedAssets, string[] movedFromAssetPaths) {
        }
    }

    [MenuItem("Elumenati/Install OmnityPostProcessingStack")]
    private static void InstallEffectHelper() {
        var o = GameObject.FindObjectOfType<Omnity>();
        if(o && o.gameObject.GetComponent<OmnityPostProcessingStack>() == null) {
            OmnityPostProcessingStack opp = o.gameObject.AddComponent<OmnityPostProcessingStack>();

            string[] guids1 = AssetDatabase.FindAssets("PostProcess", null);
            foreach(var g in guids1) {
                Debug.Log(g);
            }
            Debug.Log(guids1.Length);

            opp.ppResources = (PostProcessResources)AssetDatabase.LoadAssetAtPath("Packages/Post Processing/PostProcessing/PostProcessResources", typeof(PostProcessResources));
        } else {
            OmnityPostProcessingStack opp = o.gameObject.GetComponent<OmnityPostProcessingStack>();
            Debug.Log(AssetDatabase.GetAssetPath(opp.ppResources));
        }
    }
}

#endif